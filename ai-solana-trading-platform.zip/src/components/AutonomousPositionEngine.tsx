"use client";

import React from "react";
import { Lock, TrendingUp, TrendingDown, Target, ShieldCheck, Clock, CheckCircle2, XCircle } from "lucide-react";

interface PositionData {
  id: number;
  tokenPair: string;
  positionSide: string;
  status: string;
  solAmount: string;
  entryPrice: string;
  entryUsdc: string;
  currentPrice: string;
  takeProfitPrice: string;
  stopLossPrice: string;
  currentPnlUsdc: string;
  currentPnlPct: string;
  closePrice?: string | null;
  closeReason?: string | null;
  openSignature: string;
  closeSignature?: string | null;
  openedAt: string;
  closedAt?: string | null;
}

interface Props {
  currentPrice: number;
  openPositions: PositionData[];
  closedPositions: PositionData[];
}

export function AutonomousPositionEngine({ currentPrice, openPositions, closedPositions }: Props) {
  const activeCount = openPositions.length;

  return (
    <div className="bg-white/70 backdrop-blur-lg rounded-2xl border border-white/30 shadow-lg overflow-hidden">
      <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-emerald-50/60 to-teal-50/60 border-b border-white/20">
        <div>
          <h2 className="text-lg font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-800 to-emerald-700">
            Autonomous Positions
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {activeCount} active · Auto open & close only
          </p>
        </div>
        <span className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full bg-white/30 border border-white/20 text-slate-700">
          <Lock className="w-3.5 h-3.5 text-amber-600" />
          Manual Locked
        </span>
      </div>

      <div className="p-5 space-y-3 max-h-[420px] overflow-y-auto custom-scrollbar">
        {/* Active Positions */}
        {activeCount === 0 ? (
          <div className="text-center py-8 text-sm text-slate-400 bg-white/30 rounded-xl border border-dashed border-white/20">
            <div className="w-12 h-12 rounded-full bg-slate-100 mx-auto mb-3 flex items-center justify-center">
              <Clock className="w-6 h-6 text-slate-400" />
            </div>
            Engine scanning for optimal entry...
          </div>
        ) : (
          openPositions.map((pos) => {
            const entry = parseFloat(pos.entryPrice);
            const cur = currentPrice || parseFloat(pos.currentPrice);
            const solAmt = parseFloat(pos.solAmount);
            const pnl = (cur - entry) * solAmt;
            const pct = ((cur - entry) / entry) * 100;
            const profit = pnl >= 0;
            const tp = parseFloat(pos.takeProfitPrice);
            const sl = parseFloat(pos.stopLossPrice);
            const tpDist = (((tp - cur) / cur) * 100).toFixed(2);
            const slDist = (((cur - sl) / cur) * 100).toFixed(2);

            return (
              <div key={pos.id} className="bg-white/50 backdrop-blur-sm rounded-xl border border-white/20 p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <span className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-100 text-emerald-700">
                      {pos.positionSide}
                    </span>
                    <div>
                      <div className="text-sm font-semibold text-slate-800">{pos.tokenPair}</div>
                      <div className="text-xs text-slate-400">{solAmt.toFixed(3)} SOL</div>
                    </div>
                  </div>
                  <span className={`text-lg font-bold tabular-nums ${profit ? "text-emerald-600" : "text-rose-600"}`}>
                    {profit ? "+" : ""}${pnl.toFixed(2)} ({pct.toFixed(2)}%)
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="bg-white/30 rounded-lg px-2.5 py-2">
                    <div className="text-slate-400 text-[11px] uppercase tracking-wide">Entry</div>
                    <div className="font-semibold text-slate-800 tabular-nums">${entry.toFixed(2)}</div>
                  </div>
                  <div className="bg-emerald-50/50 rounded-lg px-2.5 py-2">
                    <div className="text-emerald-600 text-[11px] uppercase tracking-wide flex items-center gap-1">
                      <Target className="w-3 h-3" /> TP
                    </div>
                    <div className="font-semibold text-emerald-700 tabular-nums">${tp.toFixed(2)}</div>
                    <div className="text-[10px] text-emerald-500 mt-0.5">
                      {parseFloat(tpDist) <= 0 ? "Triggering..." : `${tpDist}% away`}
                    </div>
                  </div>
                  <div className="bg-rose-50/50 rounded-lg px-2.5 py-2">
                    <div className="text-rose-600 text-[11px] uppercase tracking-wide flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" /> SL
                    </div>
                    <div className="font-semibold text-rose-600 tabular-nums">${sl.toFixed(2)}</div>
                    <div className="text-[10px] text-rose-500 mt-0.5">
                      {parseFloat(slDist) <= 0 ? "Triggering..." : `${slDist}% away`}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-3 text-xs text-slate-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    Opened {new Date(pos.openedAt).toLocaleTimeString()}
                  </span>
                  <span className="flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-cyan-500" />
                    Jito Protected
                  </span>
                </div>
              </div>
            );
          })
        )}

        {/* Recently Closed */}
        {closedPositions.length > 0 && (
          <div className="pt-3 border-t border-white/20">
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              Recently Auto-Closed
            </h3>
            <div className="space-y-2">
              {closedPositions.slice(0, 4).map((c) => {
                const pnl = parseFloat(c.currentPnlUsdc || "0");
                const reason = c.closeReason || "Auto close";
                return (
                  <div key={c.id} className="flex items-center justify-between bg-white/30 rounded-lg p-2.5">
                    <div className="flex items-center gap-2">
                      {pnl >= 0 ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      ) : (
                        <XCircle className="w-4 h-4 text-rose-500" />
                      )}
                      <span className="text-xs text-slate-600 truncate">{reason}</span>
                    </div>
                    <span className={`text-sm font-semibold tabular-nums ${pnl >= 0 ? "text-emerald-600" : "text-rose-600"}`}>
                      {pnl >= 0 ? "+" : ""}${pnl.toFixed(2)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
