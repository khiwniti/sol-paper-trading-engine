"use client";

import React, { useState } from "react";
import { formatCurrency } from "@/lib/utils";
import { TrendingUp, TrendingDown, ChartCandlestick, ChartLine, Eye, EyeOff } from "lucide-react";

export interface TickData {
  id: number;
  price: string;
  open: string;
  high: string;
  low: string;
  close: string;
  volume: string;
  rsi?: string | null;
  macd?: string | null;
  signalLine?: string | null;
  ema9?: string | null;
  ema21?: string | null;
  bollingerUpper?: string | null;
  bollingerLower?: string | null;
  timestamp: string;
}

interface TradingChartProps {
  ticks: TickData[];
  currentPrice: number;
  aiTarget?: number;
  stopLoss?: number;
}

export function TradingChart({ ticks, currentPrice, aiTarget, stopLoss }: TradingChartProps) {
  const [viewMode, setViewMode] = useState<"CANDLE" | "LINE">("CANDLE");
  const [showIndicators, setShowIndicators] = useState({
    ema: true,
    bollinger: true,
    volume: false,
  });

  if (!ticks || ticks.length === 0) {
    return (
      <div className="h-96 flex items-center justify-center bg-white/60 backdrop-blur rounded-2xl border border-white/20 text-slate-500">
        <div className="flex items-center gap-2">
          <div className="animate-spin-slow">
            <div className="w-8 h-8 rounded-full border-4 border-sky-300 border-t-sky-600" />
          </div>
          <span className="text-sm font-medium text-slate-600">Loading SOL/USDC live data...</span>
        </div>
      </div>
    );
  }

  const highs = ticks.map((t) => parseFloat(t.high || t.price));
  const lows = ticks.map((t) => parseFloat(t.low || t.price));
  const minPrice = Math.min(...lows) * 0.999;
  const maxPrice = Math.max(...highs) * 1.001;
  const priceRange = maxPrice - minPrice || 1;

  const width = 900;
  const height = 380;
  const padding = { top: 24, right: 72, bottom: 32, left: 12 };
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;

  const getY = (val: number) => padding.top + chartHeight - ((val - minPrice) / priceRange) * chartHeight;
  const getX = (index: number) => padding.left + (index / (ticks.length - 1 || 1)) * chartWidth;

  const candleW = Math.max(4, Math.min(14, (chartWidth / ticks.length) * 0.8));
  const latest = ticks[ticks.length - 1];
  const first = ticks[0];
  const change = parseFloat(latest.price) - parseFloat(first.price);
  const changePct = (change / parseFloat(first.price)) * 100;
  const isUp = change >= 0;

  const buildLine = (key: keyof TickData) =>
    ticks
      .map((t, i) => {
        const v = t[key];
        if (!v) return null;
        return `${getX(i)},${getY(parseFloat(String(v)))}`;
      })
      .filter(Boolean)
      .join(" ");

  const ema9Line = buildLine("ema9");
  const ema21Line = buildLine("ema21");
  const bbUpperLine = buildLine("bollingerUpper");
  const bbLowerLine = buildLine("bollingerLower");

  const gridSteps = 5;
  const gridPrices = Array.from({ length: gridSteps }, (_, i) => minPrice + (priceRange / (gridSteps - 1)) * i);

  return (
    <div className="bg-white/70 backdrop-blur-lg rounded-2xl border border-white/30 shadow-lg overflow-hidden">
      {/* Chart Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 px-5 py-4 border-b border-white/20 bg-gradient-to-r from-sky-50/50 to-violet-50/50">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-500 to-violet-600 flex items-center justify-center shadow-lg shadow-sky-300/30">
              <ChartCandlestick className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-800 to-sky-700">
                SOL / USDC
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                JEV Strategic AI · Real-time Streaming
              </p>
            </div>
          </div>

          <div className="flex items-baseline gap-3">
            <span className="text-3xl font-black tabular-nums bg-clip-text text-transparent bg-gradient-to-r from-slate-800 to-sky-700">
              {formatCurrency(currentPrice, 2)}
            </span>
            <span
              className={`text-sm font-semibold flex items-center gap-1 px-3 py-1 rounded-full ${
                isUp
                  ? "bg-emerald-100 text-emerald-700"
                  : "bg-rose-100 text-rose-700"
              }`}
            >
              {isUp ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
              {isUp ? "+" : ""}{change.toFixed(2)} ({changePct.toFixed(2)}%)
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex bg-white/50 backdrop-blur-sm rounded-xl p-1 border border-white/20">
            <button
              onClick={() => setViewMode("CANDLE")}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                viewMode === "CANDLE"
                  ? "bg-white text-slate-800 shadow-sm"
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <ChartCandlestick className="w-4 h-4 inline" /> Candles
            </button>
            <button
              onClick={() => setViewMode("LINE")}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                viewMode === "LINE"
                  ? "bg-white text-slate-800 shadow-sm"
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <ChartLine className="w-4 h-4 inline" /> Line
            </button>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setShowIndicators(p => ({ ...p, ema: !p.ema }))}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border ${
                showIndicators.ema
                  ? "bg-sky-100 border-sky-200 text-sky-700"
                  : "bg-white/50 border-white/20 text-slate-500"
              }`}
            >
              EMA 9/21
            </button>
            <button
              onClick={() => setShowIndicators(p => ({ ...p, bollinger: !p.bollinger }))}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border ${
                showIndicators.bollinger
                  ? "bg-violet-100 border-violet-200 text-violet-700"
                  : "bg-white/50 border-white/20 text-slate-500"
              }`}
            >
              Bollinger
            </button>
          </div>
        </div>
      </div>

      {/* Main Chart SVG */}
      <div className="relative h-[380px]">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full" preserveAspectRatio="none">
          <defs>
            <linearGradient id="chartArea" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#0ea5e9" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#0ea5e9" stopOpacity="0" />
            </linearGradient>
            <linearGradient id="bullGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#059669" />
              <stop offset="100%" stopColor="#047857" />
            </linearGradient>
            <linearGradient id="bearGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f43f5e" />
              <stop offset="100%" stopColor="#dc2626" />
            </linearGradient>
            <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="2" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Grid */}
          {gridPrices.map((p, idx) => {
            const y = getY(p);
            return (
              <g key={idx}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={width - padding.right}
                  y2={y}
                  stroke="#f1f5f9"
                  strokeWidth="1"
                />
                <text
                  x={width - padding.right + 8}
                  y={y + 4}
                  fill="#94a3b8"
                  fontSize="10"
                  fontFamily="system-ui, -apple-system, sans-serif"
                  fontWeight="500"
                >
                  ${p.toFixed(2)}
                </text>
              </g>
            );
          })}

          {/* Bollinger Bands */}
          {showIndicators.bollinger && bbUpperLine && (
            <polyline
              fill="none"
              stroke="#a78bfa"
              strokeWidth="1.5"
              strokeDasharray="4 2"
              opacity="0.7"
              points={bbUpperLine}
            />
          )}
          {showIndicators.bollinger && bbLowerLine && (
            <polyline
              fill="none"
              stroke="#a78bfa"
              strokeWidth="1.5"
              strokeDasharray="4 2"
              opacity="0.7"
              points={bbLowerLine}
            />
          )}

          {/* EMA Lines */}
          {showIndicators.ema && ema9Line && (
            <polyline fill="none" stroke="#0284c7" strokeWidth="2" points={ema9Line} />
          )}
          {showIndicators.ema && ema21Line && (
            <polyline fill="none" stroke="#d97706" strokeWidth="2" points={ema21Line} />
          )}

          {/* TP/SL Lines */}
          {aiTarget && (
            <g>
              <line
                x1={padding.left}
                y1={getY(aiTarget)}
                x2={width - padding.right}
                y2={getY(aiTarget)}
                stroke="#059669"
                strokeDasharray="4 3"
                strokeWidth="1.5"
              />
              <text
                x={width - padding.right + 6}
                y={getY(aiTarget) - 6}
                fill="#059669"
                fontSize="10"
                fontWeight="700"
                fontFamily="system-ui, -apple-system, sans-serif"
              >
                TP ${aiTarget.toFixed(2)}
              </text>
            </g>
          )}
          {stopLoss && (
            <g>
              <line
                x1={padding.left}
                y1={getY(stopLoss)}
                x2={width - padding.right}
                y2={getY(stopLoss)}
                stroke="#f43f5e"
                strokeDasharray="4 3"
                strokeWidth="1.5"
              />
              <text
                x={width - padding.right + 6}
                y={getY(stopLoss) + 12}
                fill="#f43f5e"
                fontSize="10"
                fontWeight="700"
                fontFamily="system-ui, -apple-system, sans-serif"
              >
                SL ${stopLoss.toFixed(2)}
              </text>
            </g>
          )}

          {/* Candles or Line */}
          {viewMode === "CANDLE" ? (
            ticks.map((t, idx) => {
              const x = getX(idx);
              const o = parseFloat(t.open || t.price);
              const c = parseFloat(t.close || t.price);
              const h = parseFloat(t.high || t.price);
              const l = parseFloat(t.low || t.price);
              const bull = c >= o;
              const color = bull ? "url(#bullGrad)" : "url(#bearGrad)";
              const yO = getY(o);
              const yC = getY(c);
              const bodyY = Math.min(yO, yC);
              const bodyH = Math.max(3, Math.abs(yC - yO));
              return (
                <g key={idx}>
                  <line
                    x1={x}
                    y1={getY(h)}
                    x2={x}
                    y2={getY(l)}
                    stroke={bull ? "#059669" : "#f43f5e"}
                    strokeWidth="1.2"
                  />
                  <rect
                    x={x - candleW / 2}
                    y={bodyY}
                    width={candleW}
                    height={bodyH}
                    fill={color}
                    rx="1.5"
                  />
                </g>
              );
            })
          ) : (
            <>
              <path
                d={`M ${getX(0)},${getY(parseFloat(ticks[0].price))} ` +
                  ticks.map((t, i) => `L ${getX(i)},${getY(parseFloat(t.price))}`).join(" ") +
                  ` L ${getX(ticks.length - 1)},${height - padding.bottom} L ${getX(0)},${height - padding.bottom} Z`}
                fill="url(#chartArea)"
                opacity="0.6"
              />
              <polyline
                fill="none"
                stroke="#0284c7"
                strokeWidth="2.5"
                points={ticks.map((t, i) => `${getX(i)},${getY(parseFloat(t.price))}`).join(" ")}
              />
            </>
          )}

          {/* Current Price Marker */}
          <circle
            cx={getX(ticks.length - 1)}
            cy={getY(currentPrice)}
            r="5"
            fill="#0284c7"
            stroke="white"
            strokeWidth="2"
            filter="url(#glow)"
          />
          <line
            x1={padding.left}
            y1={getY(currentPrice)}
            x2={width - padding.right}
            y2={getY(currentPrice)}
            stroke="#0284c7"
            strokeDasharray="3 3"
            strokeWidth="1"
            opacity="0.7"
          />
        </svg>

        {/* Indicator Footer */}
        <div className="absolute bottom-0 left-0 right-0 px-5 py-3 bg-gradient-to-t from-white/80 to-transparent border-t border-white/20 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex gap-4 text-slate-600">
            <span>
              EMA9: <strong className="text-sky-700 tabular-nums">{latest?.ema9 ? parseFloat(latest.ema9).toFixed(2) : "--"}</strong>
            </span>
            <span>
              EMA21: <strong className="text-orange-700 tabular-nums">{latest?.ema21 ? parseFloat(latest.ema21).toFixed(2) : "--"}</strong>
            </span>
            <span>
              RSI: <strong className="text-violet-700 tabular-nums">{latest?.rsi ? parseFloat(latest.rsi).toFixed(1) : "--"}</strong>
            </span>
            {latest?.macd && (
              <span>
                MACD: <strong className="text-sky-700 tabular-nums">{parseFloat(latest.macd).toFixed(4)}</strong>
              </span>
            )}
          </div>
          <span className="text-slate-400 tabular-nums">{ticks.length} candles</span>
        </div>
      </div>
    </div>
  );
}
