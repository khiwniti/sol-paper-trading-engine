"use client";

import React, { useEffect, useState } from "react";
import { formatCurrency } from "@/lib/utils";
import { Bot, Play, Pause, Settings, ShieldCheck, Zap } from "lucide-react";

interface Props {
  config: any;
  onConfigUpdated: () => void;
  onResetBalance: () => void;
}

const STRATEGIES = [
  { v: "QUANTUM_MOMENTUM_MEV", l: "Quantum Momentum + MEV" },
  { v: "MEAN_REVERSION", l: "Mean Reversion" },
  { v: "HIGH_FREQ_SCALP", l: "High Frequency Scalper" },
  { v: "JITO_SNIPER", l: "Jito Sniper" },
];

const RISKS = ["CONSERVATIVE", "MODERATE", "AGGRESSIVE", "DEGEN"];

export function AutonomousAgentPanel({ config, onConfigUpdated, onResetBalance }: Props) {
  const [editing, setEditing] = useState(false);
  const [strategy, setStrategy] = useState("QUANTUM_MOMENTUM_MEV");
  const [riskLevel, setRiskLevel] = useState("MODERATE");
  const [tradeSize, setTradeSize] = useState("500");
  const [stopLoss, setStopLoss] = useState("2.50");
  const [takeProfit, setTakeProfit] = useState("5.00");
  const [jitoTip, setJitoTip] = useState("0.0025");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (config) {
      setStrategy(config.strategy || "QUANTUM_MOMENTUM_MEV");
      setRiskLevel(config.riskLevel || "MODERATE");
      setTradeSize(String(config.tradeSizeUsdc || "500"));
      setStopLoss(String(config.stopLossPct || "2.50"));
      setTakeProfit(String(config.takeProfitPct || "5.00"));
      setJitoTip(String(config.jitoTipSol || "0.0025"));
    }
  }, [config?.id]);

  const isActive = config?.isActive ?? true;

  const toggle = async () => {
    await fetch("/api/bot/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !isActive }),
    });
    onConfigUpdated();
  };

  const save = async () => {
    setSaving(true);
    try {
      await fetch("/api/bot/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ strategy, riskLevel, tradeSizeUsdc: tradeSize, stopLossPct: stopLoss, takeProfitPct: takeProfit, jitoTipSol: jitoTip }),
      });
      setEditing(false);
      onConfigUpdated();
    } finally {
      setSaving(false);
    }
  };

  if (editing) {
    return (
      <div className="bg-white/70 backdrop-blur-lg rounded-2xl border border-white/30 shadow-lg p-5">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-300/30">
              <Settings className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-800 to-amber-700">
                AI Strategy Configuration
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">Configure autonomous trading parameters</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setEditing(false)} className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100">
              Cancel
            </button>
            <button onClick={save} disabled={saving} className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-700 disabled:opacity-60 text-white text-xs font-semibold">
              {saving ? "Saving..." : "Save & Activate"}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <label className="block">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Trading Strategy</span>
            <select value={strategy} onChange={(e) => setStrategy(e.target.value)} className="mt-2 w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-200">
              {STRATEGIES.map((s) => <option key={s.v} value={s.v}>{s.l}</option>)}
            </select>
          </label>
          <label className="block">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Risk Level</span>
            <select value={riskLevel} onChange={(e) => setRiskLevel(e.target.value)} className="mt-2 w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-200">
              {RISKS.map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
          </label>
          <label className="block">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Trade Size (USDC)</span>
            <input type="number" value={tradeSize} onChange={(e) => setTradeSize(e.target.value)} className="mt-2 w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm tabular-nums text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-200" />
          </label>
          <label className="block">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Jito MEV Tip (SOL)</span>
            <input type="number" step="0.0001" value={jitoTip} onChange={(e) => setJitoTip(e.target.value)} className="mt-2 w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm tabular-nums text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-200" />
          </label>
          <label className="block">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Take Profit (%)</span>
            <input type="number" step="0.1" value={takeProfit} onChange={(e) => setTakeProfit(e.target.value)} className="mt-2 w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm tabular-nums text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-200" />
          </label>
          <label className="block">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Stop Loss (%)</span>
            <input type="number" step="0.1" value={stopLoss} onChange={(e) => setStopLoss(e.target.value)} className="mt-2 w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm tabular-nums text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-200" />
          </label>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white/70 backdrop-blur-lg rounded-2xl border border-white/30 shadow-lg overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-4 px-5 py-4 bg-gradient-to-r from-sky-50/60 to-violet-50/60 border-b border-white/20">
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center shadow-lg ${
              isActive
                ? "bg-gradient-to-br from-emerald-500 to-teal-600 shadow-emerald-300/30"
                : "bg-gradient-to-br from-amber-500 to-orange-600 shadow-amber-300/30"
            }`}>
              <Bot className="w-6 h-6 text-white" />
            </div>
            {isActive && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-white animate-pulse-slow" />
            )}
          </div>
          <div>
            <h2 className="text-lg font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-800 to-sky-700">
              JEV Autonomous AI Engine
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {isActive ? "ACTIVE — Auto trading enabled" : "PAUSED — No new positions"}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button onClick={onResetBalance} className="text-xs text-slate-500 hover:text-sky-700 underline underline-offset-2">
            Reset paper wallet
          </button>
          <button
            onClick={() => setEditing(true)}
            className="px-4 py-2 rounded-xl text-xs font-semibold border border-white/30 bg-white/20 hover:bg-white/30 text-slate-700 flex items-center gap-1.5"
          >
            <Settings className="w-3.5 h-3.5" /> Configure
          </button>
          <button
            onClick={toggle}
            className={`px-5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
              isActive
                ? "bg-white/30 border border-white/30 text-slate-700 hover:bg-white/40"
                : "bg-emerald-500 text-white hover:bg-emerald-600 shadow-lg shadow-emerald-300/30"
            }`}
          >
            {isActive ? <><Pause className="w-3.5 h-3.5" /> Pause Engine</> : <><Play className="w-3.5 h-3.5" /> Start Engine</>}
          </button>
        </div>
      </div>

      <div className="px-5 py-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-white/50 backdrop-blur-sm rounded-xl p-3 border border-white/20">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider block">Strategy</span>
            <span className="text-sm font-semibold text-slate-800 block mt-1 truncate">
              {(STRATEGIES.find(s => s.v === config?.strategy)?.l) || config?.strategy || "Quantum MEV"}
            </span>
          </div>
          <div className="bg-white/50 backdrop-blur-sm rounded-xl p-3 border border-white/20">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider block">Risk</span>
            <span className="text-sm font-semibold text-slate-800 block mt-1">
              {config?.riskLevel || "MODERATE"}
            </span>
          </div>
          <div className="bg-white/50 backdrop-blur-sm rounded-xl p-3 border border-white/20">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider block">Size</span>
            <span className="text-sm font-semibold text-slate-800 block mt-1 tabular-nums">
              {formatCurrency(config?.tradeSizeUsdc || 500, 0)}
            </span>
          </div>
          <div className="bg-white/50 backdrop-blur-sm rounded-xl p-3 border border-white/20">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider block">Jito Tip</span>
            <span className="text-sm font-semibold text-slate-800 block mt-1 tabular-nums">
              {config?.jitoTipSol || "0.0025"} SOL
            </span>
          </div>
        </div>

        <div className="flex flex-wrap gap-x-5 gap-y-1 mt-4 pt-3 border-t border-white/20 text-xs">
          <span className="text-slate-500">
            TP <strong className="text-emerald-600 tabular-nums">+{config?.takeProfitPct || "5.0"}%</strong>
          </span>
          <span className="text-slate-500">
            SL <strong className="text-rose-600 tabular-nums">-{config?.stopLossPct || "2.5"}%</strong>
          </span>
          <span className="text-slate-500">
            Interval <strong className="text-sky-600 tabular-nums">{config?.autoTradeIntervalSec || 6}s</strong>
          </span>
          <span className="ml-auto text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 inline text-cyan-500" /> MEV Protected
          </span>
        </div>
      </div>
    </div>
  );
}
