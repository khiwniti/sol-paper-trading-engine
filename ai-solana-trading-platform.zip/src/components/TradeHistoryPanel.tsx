"use client";

import React, { useState } from "react";
import { formatCurrency, truncateHash } from "@/lib/utils";
import { ArrowUpRight, ArrowDownRight, ExternalLink, ShieldCheck, Clock } from "lucide-react";

interface Props {
  trades: any[];
}

export function TradeHistoryPanel({ trades }: Props) {
  const [filter, setFilter] = useState<"ALL" | "BUY" | "SELL">("ALL");
  const rows = trades.filter((t) => (filter === "ALL" ? true : t.tradeType === filter));

  return (
    <div className="bg-white/70 backdrop-blur-lg rounded-2xl border border-white/30 shadow-lg overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-4 px-5 py-4 bg-gradient-to-r from-slate-50/60 to-sky-50/60 border-b border-white/20">
        <div>
          <h2 className="text-lg font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-800 to-sky-700">
            Trade History
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {trades.length} total fills · All Jito MEV protected
          </p>
        </div>
        <div className="flex bg-white/50 backdrop-blur-sm rounded-xl p-1 border border-white/20">
          {(["ALL", "BUY", "SELL"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                filter === f
                  ? "bg-white text-slate-800 shadow-sm"
                  : "text-slate-500"
              }`}
            >
              {f === "ALL" ? "All" : f === "BUY" ? "Opens" : "Closes"}
            </button>
          ))}
        </div>
      </div>

      <div className="p-5">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="text-slate-400 uppercase text-[11px] tracking-wide border-b border-white/20">
                <th className="py-3 pr-4 font-medium">Side</th>
                <th className="py-3 pr-4 font-medium">Price</th>
                <th className="py-3 pr-4 font-medium">Amount</th>
                <th className="py-3 pr-4 font-medium">Total</th>
                <th className="py-3 pr-4 font-medium">P&L</th>
                <th className="py-3 pr-4 font-medium">Reason</th>
                <th className="py-3 font-medium">Signature</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    No trades recorded yet
                  </td>
                </tr>
              ) : (
                rows.map((t: any) => {
                  const pnl = parseFloat(t.pnlUsdc || "0");
                  const buy = t.tradeType === "BUY";
                  return (
                    <tr key={t.id} className="hover:bg-white/20 transition-colors">
                      <td className="py-3 pr-4">
                        <span
                          className={`px-2 py-1 rounded-lg text-[11px] font-semibold ${
                            buy
                              ? "bg-emerald-100 text-emerald-700"
                              : "bg-rose-100 text-rose-700"
                          }`}
                        >
                          {buy ? "OPEN" : "CLOSE"}
                        </span>
                      </td>
                      <td className="py-3 pr-4 font-medium text-slate-800 tabular-nums">
                        {formatCurrency(t.price)}
                      </td>
                      <td className="py-3 pr-4 text-slate-600 tabular-nums">
                        {parseFloat(t.solAmount).toFixed(3)} SOL
                      </td>
                      <td className="py-3 pr-4 text-slate-600 tabular-nums">
                        {formatCurrency(t.usdcTotal, 0)}
                      </td>
                      <td className={`py-3 pr-4 font-semibold tabular-nums ${
                        pnl > 0 ? "text-emerald-600" : pnl < 0 ? "text-rose-600" : "text-slate-400"
                      }`}>
                        {pnl !== 0 ? `${pnl > 0 ? "+" : ""}$${pnl.toFixed(2)}` : "—"}
                      </td>
                      <td className="py-3 pr-4 max-w-[200px] truncate text-slate-500 text-[11px]" title={t.reason}>
                        {t.reason}
                      </td>
                      <td className="py-3 text-slate-400 text-[11px] whitespace-nowrap">
                        <a
                          href={`https://solscan.io/tx/${t.signature}`}
                          target="_blank"
                          rel="noreferrer"
                          className="hover:text-sky-600 underline underline-offset-2"
                          title={t.signature}
                        >
                          {truncateHash(t.signature, 6, 4)}
                          <ExternalLink className="w-3 h-3 inline" />
                        </a>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="px-5 py-3 border-t border-white/20 bg-slate-50/50">
        <p className="text-xs text-slate-400">
          All transactions routed via Jito private mempool · Sandwich attack protected
        </p>
      </div>
    </div>
  );
}
