"use client";

import React, { useState } from "react";
import { formatCurrency } from "@/lib/utils";
import { Zap, ShieldCheck, Radio, Activity, Target, Clock } from "lucide-react";

interface Props {
  signals: any[];
  mevEvents: any[];
}

export function SignalsAndMevPanel({ signals, mevEvents }: Props) {
  const [tab, setTab] = useState<"SIGNALS" | "MEV">("SIGNALS");

  return (
    <div className="bg-white/70 backdrop-blur-lg rounded-2xl border border-white/30 shadow-lg overflow-hidden">
      <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-violet-50/60 to-purple-50/60 border-b border-white/20">
        <div className="flex bg-white/50 backdrop-blur-sm rounded-xl p-1 border border-white/20">
          <button
            onClick={() => setTab("SIGNALS")}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              tab === "SIGNALS"
                ? "bg-white text-violet-700 shadow-sm"
                : "text-slate-500"
            }`}
          >
            AI Signals ({signals.length})
          </button>
          <button
            onClick={() => setTab("MEV")}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              tab === "MEV"
                ? "bg-white text-violet-700 shadow-sm"
                : "text-slate-500"
            }`}
          >
            MEV Bundles ({mevEvents.length})
          </button>
        </div>
        <span className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full bg-white/30 border border-white/20 text-emerald-600">
          <Radio className="w-3.5 h-3.5 animate-pulse-slow" />
          Live Stream
        </span>
      </div>

      <div className="p-5 space-y-3 max-h-[380px] overflow-y-auto custom-scrollbar">
        {tab === "SIGNALS" ? (
          signals.length === 0 ? (
            <div className="text-center py-8 text-sm text-slate-400">
              <Activity className="w-8 h-8 mx-auto mb-2 text-slate-400 animate-spin-slow" />
              Awaiting AI signal...
            </div>
          ) : (
            signals.map((s: any, idx: number) => {
              const isBuy = String(s.action).includes("BUY");
              const isMev = String(s.action).includes("MEV");
              return (
                <div
                  key={s.id}
                  className="bg-white/50 backdrop-blur-sm rounded-xl border border-white/20 p-4"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                          isBuy
                            ? "bg-emerald-100 text-emerald-700"
                            : isMev
                            ? "bg-cyan-100 text-cyan-700"
                            : "bg-rose-100 text-rose-700"
                        }`}
                      >
                        {s.action}
                      </span>
                      <div>
                        <div className="text-sm font-semibold text-slate-800">{s.pair}</div>
                        <div className="text-xs text-slate-400">
                          Confidence: <strong className="text-violet-600">{s.confidence}%</strong>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-slate-400">{new Date(s.createdAt).toLocaleTimeString()}</div>
                    </div>
                  </div>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed line-clamp-2">{s.rationale}</p>
                  <div className="flex gap-4 mt-3 text-xs">
                    <span className="text-slate-500">
                      TP <strong className="text-emerald-600 tabular-nums">{formatCurrency(s.targetPrice, 1)}</strong>
                    </span>
                    <span className="text-slate-500">
                      SL <strong className="text-rose-600 tabular-nums">{formatCurrency(s.stopLossPrice, 1)}</strong>
                    </span>
                    <span className={`ml-auto text-xs font-medium px-2 py-0.5 rounded-full ${
                      s.executed ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"
                    }`}>
                      {s.executed ? "Executed" : "Pending"}
                    </span>
                  </div>
                </div>
              );
            })
          )
        ) : mevEvents.length === 0 ? (
          <div className="text-center py-8 text-sm text-slate-400">
            <ShieldCheck className="w-8 h-8 mx-auto mb-2 text-slate-400" />
            No MEV bundles yet...
          </div>
        ) : (
          mevEvents.map((m: any) => (
            <div
              key={m.id}
              className="flex items-center justify-between bg-white/50 backdrop-blur-sm rounded-xl border border-white/20 p-3"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-violet-600 flex items-center justify-center shadow-sm shadow-cyan-300/30">
                  <ShieldCheck className="w-4 h-4 text-white" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-slate-800">{m.protectionType}</div>
                  <div className="text-[11px] text-slate-400 truncate max-w-[140px]" title={m.jitoLeader}>
                    {m.jitoLeader}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-semibold text-emerald-600 tabular-nums">+{m.blockRewardSol} SOL</div>
                <div className="text-[11px] text-slate-400">
                  Slot #{m.slot} · {new Date(m.timestamp).toLocaleTimeString()}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
