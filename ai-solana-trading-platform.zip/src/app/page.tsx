"use client";

import React, { useState, useEffect, useCallback } from "react";
import { TradingChart } from "@/components/TradingChart";
import { AutonomousPositionEngine } from "@/components/AutonomousPositionEngine";
import { AutonomousAgentPanel } from "@/components/AutonomousAgentPanel";
import { SignalsAndMevPanel } from "@/components/SignalsAndMevPanel";
import { TradeHistoryPanel } from "@/components/TradeHistoryPanel";
import { formatCurrency } from "@/lib/utils";
import { Pause, Play, RefreshCw, Bot, ShieldCheck, Cpu, Zap } from "lucide-react";

export default function JEVTradingPlatform() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [streaming, setStreaming] = useState(true);
  const [lastUpdated, setLastUpdated] = useState("");

  const fetchState = useCallback(async () => {
    try {
      const res = await fetch("/api/market/state");
      if (!res.ok) throw new Error("load failed");
      const json = await res.json();
      setData(json);
      setLastUpdated(new Date().toLocaleTimeString());
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  const triggerTick = useCallback(async () => {
    try {
      await fetch("/api/market/state", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      await fetchState();
    } catch (e) {
      console.error(e);
    }
  }, [fetchState]);

  useEffect(() => {
    fetchState();
  }, [fetchState]);

  useEffect(() => {
    if (!streaming) return;
    const id = setInterval(triggerTick, 4000);
    return () => clearInterval(id);
  }, [streaming, triggerTick]);

  const handleResetBalance = async () => {
    await fetch("/api/bot/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ resetPaperBalance: true }),
    });
    fetchState();
  };

  const currentPrice = data?.metrics?.currentPrice ?? 182.5;
  const config = data?.config;
  const ticks = data?.ticks || [];
  const trades = data?.trades || [];
  const signals = data?.signals || [];
  const mevEvents = data?.mevEvents || [];
  const metrics = data?.metrics || {};

  const netWorth = parseFloat(config?.paperUsdcBalance || "10000") + parseFloat(config?.paperSolBalance || "25") * currentPrice;
  const totalPnl = parseFloat(metrics.totalPnlUsdc || "0");
  const totalTrades = metrics.totalTrades || 0;
  const winRate = metrics.winRate || "0.0";
  const activePos = data?.openPositions?.[0];
  const tp = activePos ? parseFloat(activePos.takeProfitPrice) : signals[0] ? parseFloat(signals[0].targetPrice) : undefined;
  const sl = activePos ? parseFloat(activePos.stopLossPrice) : signals[0] ? parseFloat(signals[0].stopLossPrice) : undefined;
  const openCount = data?.openPositions?.length || 0;

  const stats = [
    { label: "Net Worth", value: formatCurrency(netWorth), tone: "text-slate-800" },
    { label: "USDC Balance", value: formatCurrency(config?.paperUsdcBalance || 0), tone: "text-slate-800" },
    { label: "SOL Balance", value: `${parseFloat(config?.paperSolBalance || "0").toFixed(3)} SOL`, tone: "text-slate-800" },
    { label: "Total P&L", value: `${totalPnl >= 0 ? "+" : ""}$${totalPnl.toFixed(2)}`, tone: totalPnl >= 0 ? "text-emerald-600" : "text-rose-600" },
    { label: "Win Rate", value: `${winRate}%`, tone: "text-violet-600" },
    { label: "Total Trades", value: String(totalTrades), tone: "text-sky-600" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-sky-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-500 via-violet-600 to-emerald-500 flex items-center justify-center shadow-lg shadow-sky-300/30">
                <Cpu className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-800 to-sky-700">
                  SolAI JEV Platform
                </h1>
                <p className="text-xs text-slate-500">
                  Strategic Autonomous Trading · Jito MEV Protected · 100% Auto Open/Close
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setStreaming(!streaming)}
                className="flex items-center gap-1.5 text-xs font-medium px-4 py-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 shadow-sm"
              >
                {streaming ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                {streaming ? "Pause Stream" : "Resume"}
              </button>
              <button
                onClick={fetchState}
                className="p-2.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-500"
                title="Refresh"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 space-y-5">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {stats.map((s) => (
            <div
              key={s.label}
              className="bg-white/60 backdrop-blur-lg rounded-2xl border border-white/30 p-4 shadow-sm"
            >
              <div className="text-xs font-medium text-slate-500 uppercase tracking-wider truncate">{s.label}</div>
              <div className={`text-xl font-bold tabular-nums mt-1.5 ${s.tone}`}>{s.value}</div>
            </div>
          ))}
        </div>

        {/* AI Engine Control */}
        <AutonomousAgentPanel
          config={config}
          onConfigUpdated={fetchState}
          onResetBalance={handleResetBalance}
        />

        {/* Chart + Positions */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2">
            <TradingChart ticks={ticks} currentPrice={currentPrice} aiTarget={tp} stopLoss={sl} />
          </div>
          <AutonomousPositionEngine
            currentPrice={currentPrice}
            openPositions={data?.openPositions || []}
            closedPositions={data?.closedPositions || []}
          />
        </div>

        {/* Signals + History */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-1">
            <SignalsAndMevPanel signals={signals} mevEvents={mevEvents} />
          </div>
          <div className="lg:col-span-2">
            <TradeHistoryPanel trades={trades} />
          </div>
        </div>

        {/* Footer */}
        <div className="text-center text-xs text-slate-400 py-4">
          <span className="flex items-center justify-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-500" />
            JEV (Jito MEV) Strategic AI Platform · Last update: {lastUpdated || "…"} · {openCount} positions active
          </span>
        </div>
      </main>
    </div>
  );
}
