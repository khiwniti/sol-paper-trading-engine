import { NextResponse } from "next/server";
import { db } from "@/db";
import { botConfig } from "@/db/schema";
import { sql } from "drizzle-orm";
import { ensureDbSeeded } from "@/lib/seed";

export async function GET() {
  await ensureDbSeeded();
  const configs = await db.select().from(botConfig).limit(1);
  return NextResponse.json({ config: configs[0] || null });
}

export async function POST(req: Request) {
  try {
    await ensureDbSeeded();
    const body = await req.json();

    const [existing] = await db.select().from(botConfig).limit(1);
    if (!existing) {
      return NextResponse.json({ error: "Config not found" }, { status: 404 });
    }

    const updateData: Record<string, any> = {
      updated_at: new Date(),
    };

    if (body.isActive !== undefined) updateData.isActive = Boolean(body.isActive);
    if (body.strategy) updateData.strategy = String(body.strategy);
    if (body.riskLevel) updateData.riskLevel = String(body.riskLevel);
    if (body.tradeSizeUsdc) updateData.tradeSizeUsdc = String(body.tradeSizeUsdc);
    if (body.stopLossPct) updateData.stopLossPct = String(body.stopLossPct);
    if (body.takeProfitPct) updateData.takeProfitPct = String(body.takeProfitPct);
    if (body.jitoTipSol) updateData.jitoTipSol = String(body.jitoTipSol);
    if (body.jitoBundleProtection !== undefined) updateData.jitoBundleProtection = Boolean(body.jitoBundleProtection);
    if (body.maxSlippagePct) updateData.maxSlippagePct = String(body.maxSlippagePct);
    if (body.autoTradeIntervalSec) updateData.autoTradeIntervalSec = Number(body.autoTradeIntervalSec);

    // Reset balances if requested
    if (body.resetPaperBalance) {
      updateData.paperUsdcBalance = "10000.0000";
      updateData.paperSolBalance = "25.000000";
    }

    const [updated] = await db
      .update(botConfig)
      .set(updateData)
      .where(sql`${botConfig.id} = ${existing.id}`)
      .returning();

    return NextResponse.json({ success: true, config: updated });
  } catch (error: unknown) {
    console.error("POST /api/bot/config error:", error);
    return NextResponse.json({ error: (error as Error).message }, { status: 500 });
  }
}
