import { NextResponse } from "next/server";
import { db } from "@/db";
import { botConfig, solPriceTicks, trades, aiSignals, mevBundleEvents, positions } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { ensureDbSeeded } from "@/lib/seed";
import { calculateEMA, calculateRSI, calculateBollingerBands, generateSolanaSignature } from "@/lib/indicators";

export async function GET() {
  try {
    await ensureDbSeeded();

    const [configs, latestTicks, latestTrades, latestSignals, mevEvents, openPosList, closedPosList] = await Promise.all([
      db.select().from(botConfig).limit(1),
      db.select().from(solPriceTicks).orderBy(desc(solPriceTicks.timestamp)).limit(60),
      db.select().from(trades).orderBy(desc(trades.createdAt)).limit(25),
      db.select().from(aiSignals).orderBy(desc(aiSignals.createdAt)).limit(15),
      db.select().from(mevBundleEvents).orderBy(desc(mevBundleEvents.timestamp)).limit(15),
      db.select().from(positions).where(eq(positions.status, "OPEN")).orderBy(desc(positions.openedAt)),
      db.select().from(positions).where(eq(positions.status, "CLOSED")).orderBy(desc(positions.closedAt)).limit(10),
    ]);

    const config = configs[0] || null;
    const ticks = latestTicks.reverse();
    const currentPrice = ticks.length > 0 ? parseFloat(ticks[ticks.length - 1].price) : 182.5;

    // Recalculate dynamic unrealized PnL for open positions
    const openPositions = openPosList.map(pos => {
      const entry = parseFloat(pos.entryPrice);
      const solAmt = parseFloat(pos.solAmount);
      const curPnlUsdc = (currentPrice - entry) * solAmt;
      const curPnlPct = ((currentPrice - entry) / entry) * 100;
      return {
        ...pos,
        currentPrice: currentPrice.toFixed(4),
        currentPnlUsdc: curPnlUsdc.toFixed(4),
        currentPnlPct: curPnlPct.toFixed(2),
      };
    });

    // Summary calculations
    const allTrades = await db.select().from(trades);
    const totalPnlUsdc = allTrades.reduce((acc, t) => acc + (parseFloat(t.pnlUsdc || "0")), 0);
    const winTrades = allTrades.filter(t => parseFloat(t.pnlUsdc || "0") > 0);
    const winRate = allTrades.length > 0 ? (winTrades.length / allTrades.length) * 100 : 0;

    return NextResponse.json({
      config,
      ticks,
      trades: latestTrades,
      signals: latestSignals,
      mevEvents,
      openPositions,
      closedPositions: closedPosList,
      metrics: {
        totalTrades: allTrades.length,
        winRate: winRate.toFixed(1),
        totalPnlUsdc: totalPnlUsdc.toFixed(2),
        currentPrice,
        openPositionsCount: openPositions.length,
      },
      serverTime: new Date().toISOString(),
    });
  } catch (error: unknown) {
    console.error("GET /api/market/state error:", error);
    return NextResponse.json({ error: (error as Error).message }, { status: 500 });
  }
}

// POST endpoint: simulates market price movement and executes autonomous open/close loop
export async function POST(req: Request) {
  try {
    await ensureDbSeeded();
    const body = await req.json().catch(() => ({}));

    // Fetch latest tick history
    const lastTickResult = await db.select().from(solPriceTicks).orderBy(desc(solPriceTicks.timestamp)).limit(30);
    const prevTick = lastTickResult[0];
    const prevPrice = prevTick ? parseFloat(prevTick.price) : 182.50;

    // Realistic market price movement with momentum and micro-swings
    const rand = Math.random();
    let drift = (rand - 0.492) * 1.05;
    if (rand > 0.88) drift *= 1.8; // sudden burst
    else if (rand < 0.12) drift *= 1.6;

    const newPrice = Math.max(90, +(prevPrice + drift).toFixed(4));
    const open = prevPrice;
    const high = +(Math.max(open, newPrice) + Math.random() * 0.42).toFixed(4);
    const low = +(Math.min(open, newPrice) - Math.random() * 0.42).toFixed(4);
    const close = newPrice;
    const volume = +(18000 + Math.random() * 75000).toFixed(2);

    // Compute technicals from historical window
    const priceHistory = lastTickResult.map(t => parseFloat(t.price)).reverse();
    priceHistory.push(close);

    const rsi = calculateRSI(priceHistory);
    const ema9 = calculateEMA(priceHistory, 9);
    const ema21 = calculateEMA(priceHistory, 21);
    const bb = calculateBollingerBands(priceHistory);
    const macd = +(ema9 - ema21).toFixed(4);
    const signalLine = +(macd * 0.85).toFixed(4);

    const [insertedTick] = await db.insert(solPriceTicks).values({
      price: close.toString(),
      open: open.toString(),
      high: high.toString(),
      low: low.toString(),
      close: close.toString(),
      volume: volume.toString(),
      rsi: rsi.toString(),
      macd: macd.toString(),
      signalLine: signalLine.toString(),
      ema9: ema9.toString(),
      ema21: ema21.toString(),
      bollingerUpper: bb.upper.toString(),
      bollingerLower: bb.lower.toString(),
      timestamp: new Date(),
    }).returning();

    // Fetch bot config
    const [config] = await db.select().from(botConfig).limit(1);

    const autoClosedPositions: any[] = [];
    let autoOpenedPosition: any = null;
    let newSignal: any = null;

    if (config && config.isActive) {
      let currentUsdc = parseFloat(config.paperUsdcBalance || "10000");
      let currentSol = parseFloat(config.paperSolBalance || "25");

      // 1. EVALUATE & AUTO-CLOSE ACTIVE OPEN POSITIONS
      const openPositions = await db.select().from(positions).where(eq(positions.status, "OPEN"));

      for (const pos of openPositions) {
        const entryPrice = parseFloat(pos.entryPrice);
        const takeProfitPrice = parseFloat(pos.takeProfitPrice);
        const stopLossPrice = parseFloat(pos.stopLossPrice);
        const solAmount = parseFloat(pos.solAmount);

        let shouldClose = false;
        let closeReason = "";

        if (close >= takeProfitPrice) {
          shouldClose = true;
          closeReason = `AUTO_TAKE_PROFIT (Reached $${takeProfitPrice.toFixed(2)})`;
        } else if (close <= stopLossPrice) {
          shouldClose = true;
          closeReason = `AUTO_STOP_LOSS (Triggered at $${stopLossPrice.toFixed(2)})`;
        } else if (rsi > 70 && (close - entryPrice) > 0.5) {
          // AI momentum overbought take-profit exit
          shouldClose = true;
          closeReason = `AI_REVERSAL_EXIT (RSI ${rsi} Overbought Harvest)`;
        }

        if (shouldClose) {
          const closeSignature = generateSolanaSignature();
          const realizedPnlUsdc = (close - entryPrice) * solAmount;
          const realizedPnlPct = ((close - entryPrice) / entryPrice) * 100;
          const usdcReturn = solAmount * close;
          const fee = 0.05;

          // Update position to CLOSED
          const [closedPos] = await db.update(positions).set({
            status: "CLOSED",
            closePrice: close.toString(),
            closeReason,
            closeSignature,
            currentPnlUsdc: realizedPnlUsdc.toFixed(4),
            currentPnlPct: realizedPnlPct.toFixed(2),
            closedAt: new Date(),
          }).where(eq(positions.id, pos.id)).returning();

          autoClosedPositions.push(closedPos);

          // Update wallet balances
          currentUsdc = currentUsdc + usdcReturn - fee;
          currentSol = Math.max(0, currentSol - solAmount);

          // Log in trades audit
          await db.insert(trades).values({
            tradeType: "SELL",
            tokenPair: "SOL/USDC",
            solAmount: solAmount.toString(),
            price: close.toString(),
            usdcTotal: usdcReturn.toString(),
            feeUsdc: fee.toString(),
            jitoTipSol: config.jitoTipSol,
            mevStatus: "BUNDLE_CONFIRMED",
            signature: closeSignature,
            pnlUsdc: realizedPnlUsdc.toFixed(4),
            pnlPct: realizedPnlPct.toFixed(2),
            reason: `Auto-closed by Engine: ${closeReason}`,
            aiConfidence: "96.40",
            createdAt: new Date(),
          });

          // Jito bundle event
          await db.insert(mevBundleEvents).values({
            bundleHash: closeSignature.slice(0, 44),
            jitoLeader: "Jito-BlockLogic-Validator",
            slot: 289420000 + Math.floor(Math.random() * 500),
            blockRewardSol: (0.002 + Math.random() * 0.004).toFixed(6),
            protectionType: "SANDWICH_DEFENSE",
            status: "LANDED",
            profitSol: (0.0018 + Math.random() * 0.005).toFixed(6),
            timestamp: new Date(),
          });
        } else {
          // Update live unrealized PnL in open position
          const unrealizedPnlUsdc = (close - entryPrice) * solAmount;
          const unrealizedPnlPct = ((close - entryPrice) / entryPrice) * 100;
          await db.update(positions).set({
            currentPrice: close.toString(),
            currentPnlUsdc: unrealizedPnlUsdc.toFixed(4),
            currentPnlPct: unrealizedPnlPct.toFixed(2),
          }).where(eq(positions.id, pos.id));
        }
      }

      // 2. EVALUATE & AUTO-OPEN NEW POSITIONS
      // Check remaining open positions count
      const activePositions = await db.select().from(positions).where(eq(positions.status, "OPEN"));
      const maxConcurrentPositions = 2;

      const isOversold = rsi < 40 || close < bb.lower;
      const isCrossUp = ema9 > ema21 && macd > signalLine;
      const stochasticTrigger = Math.random() > 0.65; // realistic periodic auto execution

      if (activePositions.length < maxConcurrentPositions && (isOversold || isCrossUp || stochasticTrigger)) {
        const tradeSizeUsdc = parseFloat(config.tradeSizeUsdc || "500");
        const takeProfitPct = parseFloat(config.takeProfitPct || "2.5");
        const stopLossPct = parseFloat(config.stopLossPct || "2.0");

        if (currentUsdc >= tradeSizeUsdc && tradeSizeUsdc > 20) {
          const solAmt = +(tradeSizeUsdc / close).toFixed(6);
          const tpPrice = +(close * (1 + takeProfitPct / 100)).toFixed(4);
          const slPrice = +(close * (1 - stopLossPct / 100)).toFixed(4);
          const openSig = generateSolanaSignature();
          const fee = 0.05;

          // Insert newly opened position
          const [newPos] = await db.insert(positions).values({
            tokenPair: "SOL/USDC",
            positionSide: "LONG",
            status: "OPEN",
            solAmount: solAmt.toString(),
            entryPrice: close.toString(),
            entryUsdc: tradeSizeUsdc.toString(),
            currentPrice: close.toString(),
            takeProfitPrice: tpPrice.toString(),
            stopLossPrice: slPrice.toString(),
            currentPnlUsdc: "0.0000",
            currentPnlPct: "0.00",
            openSignature: openSig,
            jitoTipSol: config.jitoTipSol,
            openedAt: new Date(),
          }).returning();

          autoOpenedPosition = newPos;

          // Update balances
          currentUsdc = currentUsdc - tradeSizeUsdc - fee;
          currentSol = currentSol + solAmt;

          // Log in trades audit
          await db.insert(trades).values({
            tradeType: "BUY",
            tokenPair: "SOL/USDC",
            solAmount: solAmt.toString(),
            price: close.toString(),
            usdcTotal: tradeSizeUsdc.toString(),
            feeUsdc: fee.toString(),
            jitoTipSol: config.jitoTipSol,
            mevStatus: "BUNDLE_CONFIRMED",
            signature: openSig,
            pnlUsdc: "0.0000",
            pnlPct: "0.00",
            reason: `Auto-opened by AI Engine: RSI (${rsi.toFixed(1)}) Momentum + Jito MEV Bundle`,
            aiConfidence: (88 + Math.random() * 9).toFixed(2),
            createdAt: new Date(),
          });

          // Generate AI signal
          const [sig] = await db.insert(aiSignals).values({
            pair: "SOL/USDC",
            action: "STRONG_BUY",
            confidence: (90 + Math.random() * 8).toFixed(2),
            targetPrice: tpPrice.toString(),
            stopLossPrice: slPrice.toString(),
            rationale: `Autonomous Entry: Detected positive volume delta on Raydium CLMM with Jito ${config.jitoTipSol} SOL private bundle tip. Auto-TP set to $${tpPrice}.`,
            mevPayload: {
              jitoTip: `${config.jitoTipSol} SOL`,
              antiFrontrun: true,
              protection: "Active Sandwich Defense",
            },
            executed: true,
            createdAt: new Date(),
          }).returning();

          newSignal = sig;

          // Jito MEV Bundle event
          await db.insert(mevBundleEvents).values({
            bundleHash: openSig.slice(0, 44),
            jitoLeader: "Edgevana-Jito-Relayer-HQ",
            slot: 289421000 + Math.floor(Math.random() * 500),
            blockRewardSol: (0.0018 + Math.random() * 0.004).toFixed(6),
            protectionType: "SANDWICH_DEFENSE",
            status: "LANDED",
            profitSol: (0.0022 + Math.random() * 0.007).toFixed(6),
            timestamp: new Date(),
          });
        }
      }

      // Persist updated balances
      await db.update(botConfig).set({
        paperUsdcBalance: currentUsdc.toFixed(4),
        paperSolBalance: currentSol.toFixed(6),
        lastRunAt: new Date(),
        updated_at: new Date(),
      }).where(eq(botConfig.id, config.id));
    }

    return NextResponse.json({
      success: true,
      tick: insertedTick,
      autoOpenedPosition,
      autoClosedPositions,
      signal: newSignal,
    });
  } catch (error: unknown) {
    console.error("POST /api/market/state error:", error);
    return NextResponse.json({ error: (error as Error).message }, { status: 500 });
  }
}
