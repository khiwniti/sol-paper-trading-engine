import { NextResponse } from "next/server";
import { db } from "@/db";
import { botConfig, trades, solPriceTicks } from "@/db/schema";
import { desc, sql } from "drizzle-orm";
import { generateSolanaSignature } from "@/lib/indicators";
import { ensureDbSeeded } from "@/lib/seed";

export async function POST(req: Request) {
  // User manual execution is strictly disallowed. The engine runs 100% autonomously.
  return NextResponse.json(
    {
      error: "Manual execution disabled: Platform is strictly autonomous. All positions are opened, managed, and closed exclusively by the AI Engine to prevent MEV sandwich interference.",
      mode: "AUTONOMOUS_ONLY",
    },
    { status: 403 }
  );
}
