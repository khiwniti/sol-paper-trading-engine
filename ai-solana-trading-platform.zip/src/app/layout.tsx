import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SolAI | JEV Strategic Autonomous Trading Platform",
  description:
    "Stunning JEV (Jito MEV) Strategic AI Autonomous Trading Platform for SOL/USDC with real-time streaming, advanced indicators, and complete autonomous position management.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="min-h-screen">
        {children}
      </body>
    </html>
  );
}
