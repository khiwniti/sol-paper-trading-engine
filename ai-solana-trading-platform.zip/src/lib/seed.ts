import { db } from "@/db";
import { botConfig, solPriceTicks, trades, aiSignals, mevBundleEvents, positions } from "@/db/schema";
import { generateInitialSeedTicks, generateSolanaSignature } from "./indicators";
import { sql } from "drizzle-orm";

let isInitialized = false;

export async function ensureDbSeeded() {
  if (isInitialized) return;

  try {
    // Check if bot config exists
    const configs = await db.select().from(botConfig).limit(1);
    if (configs.length === 0) {
      await db.insert(botConfig).values({
        name: "SolAI Quantum Jito-MEV Agent",
        isActive: true,
        strategy: "QUANTUM_MOMENTUM_MEV",
        riskLevel: "MODERATE",
        initialUsdcBalance: "10000.0000",
        paperUsdcBalance: "9240.5000",
        paperSolBalance: "29.742000",
        stopLossPct: "2.50",
        takeProfitPct: "5.00",
        jitoTipSol: "0.002500",
        jitoBundleProtection: true,
        maxSlippagePct: "0.40",
        tradeSizeUsdc: "500.00",
        autoTradeIntervalSec: 5,
        lastRunAt: new Date(),
      });
    }

    // Check ticks
    const tickCountRes = await db.select({ count: sql<number>`count(*)` }).from(solPriceTicks);
    const count = Number(tickCountRes[0]?.count || 0);

    if (count < 20) {
      const seedTicks = generateInitialSeedTicks(182.45, 45);
      for (const t of seedTicks) {
        await db.insert(solPriceTicks).values({
          price: t.price.toString(),
          open: t.open.toString(),
          high: t.high.toString(),
          low: t.low.toString(),
          close: t.close.toString(),
          volume: t.volume.toString(),
          rsi: t.rsi ? t.rsi.toString() : "50.0",
          macd: t.macd ? t.macd.toString() : "0.12",
          signalLine: t.signalLine ? t.signalLine.toString() : "0.08",
          ema9: t.ema9 ? t.ema9.toString() : t.price.toString(),
          ema21: t.ema21 ? t.ema21.toString() : t.price.toString(),
          bollingerUpper: t.bollingerUpper ? t.bollingerUpper.toString() : (t.price * 1.02).toString(),
          bollingerLower: t.bollingerLower ? t.bollingerLower.toString() : (t.price * 0.98).toString(),
          timestamp: new Date(t.timestamp),
        });
      }
    }

    // Check trades
    const tradesCount = await db.select({ count: sql<number>`count(*)` }).from(trades);
    if (Number(tradesCount[0]?.count || 0) === 0) {
      await db.insert(trades).values([
        {
          tradeType: "BUY",
          tokenPair: "SOL/USDC",
          solAmount: "2.750000",
          price: "181.8000",
          usdcTotal: "499.9500",
          feeUsdc: "0.0500",
          jitoTipSol: "0.002500",
          mevStatus: "BUNDLE_CONFIRMED",
          signature: generateSolanaSignature(),
          pnlUsdc: "18.4200",
          pnlPct: "3.68",
          reason: "RSI Oversold 28.4 + Whale Sandwich Defense detected on Raydium CLMM",
          aiConfidence: "92.40",
          createdAt: new Date(Date.now() - 3600000 * 2),
        },
        {
          tradeType: "SELL",
          tokenPair: "SOL/USDC",
          solAmount: "1.450000",
          price: "183.2000",
          usdcTotal: "265.6400",
          feeUsdc: "0.0350",
          jitoTipSol: "0.002000",
          mevStatus: "BACKRUN_SNIPED",
          signature: generateSolanaSignature(),
          pnlUsdc: "12.8000",
          pnlPct: "4.82",
          reason: "EMA 9/21 Bearish Crossover exit + Jito MEV private tip rebate",
          aiConfidence: "89.10",
          createdAt: new Date(Date.now() - 3600000 * 1),
        },
        {
          tradeType: "BUY",
          tokenPair: "SOL/USDC",
          solAmount: "2.800000",
          price: "182.1000",
          usdcTotal: "509.8800",
          feeUsdc: "0.0510",
          jitoTipSol: "0.002500",
          mevStatus: "FRONTRUN_PROTECTED",
          signature: generateSolanaSignature(),
          pnlUsdc: "8.1500",
          pnlPct: "1.60",
          reason: "Bollinger lower bounce with zero sandwich slippage via Jito MEV bundle",
          aiConfidence: "94.75",
          createdAt: new Date(Date.now() - 1800000),
        },
      ]);
    }

    // Check signals
    const signalCount = await db.select({ count: sql<number>`count(*)` }).from(aiSignals);
    if (Number(signalCount[0]?.count || 0) === 0) {
      await db.insert(aiSignals).values([
        {
          pair: "SOL/USDC",
          action: "STRONG_BUY",
          confidence: "94.80",
          targetPrice: "186.5000",
          stopLossPrice: "179.2000",
          rationale: "Deep liquidity wall on Orca Whirlpools + 0.0035 SOL tip Jito bundle front-run protection confirmed. RSI at 34 oversold.",
          mevPayload: {
            jitoTip: "0.0025 SOL",
            slippageProtection: "Active",
            targetPool: "Raydium CPMM",
            sandwichRiskScore: "0.02 (Low)",
          },
          executed: true,
          createdAt: new Date(Date.now() - 1200000),
        },
        {
          pair: "SOL/USDC",
          action: "MEV_ARBITRAGE",
          confidence: "91.20",
          targetPrice: "184.2000",
          stopLossPrice: "181.1000",
          rationale: "Cross-DEX spread (Orca vs Raydium) at 42 bps. Backrun opportunity detected via validator block leader 8xP...",
          mevPayload: {
            jitoTip: "0.0040 SOL",
            spreadBps: 42,
            netEstimatedProfitUsdc: "+$14.20",
          },
          executed: false,
          createdAt: new Date(Date.now() - 300000),
        },
      ]);
    }

    // Check MEV bundle events
    const mevCount = await db.select({ count: sql<number>`count(*)` }).from(mevBundleEvents);
    if (Number(mevCount[0]?.count || 0) === 0) {
      const leaders = [
        "Jito-BlockLogic-Validator-01",
        "Shinobi-Systems-Jito-Node",
        "Edgevana-Jito-Relayer-HQ",
        "Helius-Mev-Bundler-04",
      ];
      for (let i = 0; i < 5; i++) {
        await db.insert(mevBundleEvents).values({
          bundleHash: generateSolanaSignature().slice(0, 44),
          jitoLeader: leaders[i % leaders.length],
          slot: 289410200 + i * 14,
          blockRewardSol: (0.0015 + Math.random() * 0.004).toFixed(6),
          protectionType: i % 2 === 0 ? "SANDWICH_DEFENSE" : "ARB_BACKRUN",
          status: "LANDED",
          profitSol: (0.002 + Math.random() * 0.009).toFixed(6),
          timestamp: new Date(Date.now() - (5 - i) * 120000),
        });
      }
    }

    // Check positions (open & closed positions managed autonomously)
    const positionCount = await db.select({ count: sql<number>`count(*)` }).from(positions);
    if (Number(positionCount[0]?.count || 0) === 0) {
      await db.insert(positions).values([
        {
          tokenPair: "SOL/USDC",
          positionSide: "LONG",
          status: "OPEN",
          solAmount: "2.800000",
          entryPrice: "182.1000",
          entryUsdc: "509.8800",
          currentPrice: "182.4500",
          takeProfitPrice: "186.6500", // +2.5%
          stopLossPrice: "177.5500",  // -2.5%
          currentPnlUsdc: "0.9800",
          currentPnlPct: "0.19",
          openSignature: generateSolanaSignature(),
          jitoTipSol: "0.002500",
          openedAt: new Date(Date.now() - 420000),
        },
        {
          tokenPair: "SOL/USDC",
          positionSide: "LONG",
          status: "CLOSED",
          solAmount: "2.750000",
          entryPrice: "178.2000",
          entryUsdc: "490.0500",
          currentPrice: "183.4000",
          takeProfitPrice: "183.4000",
          stopLossPrice: "174.5000",
          currentPnlUsdc: "14.3000",
          currentPnlPct: "2.92",
          closePrice: "183.4000",
          closeReason: "AUTO_TAKE_PROFIT",
          openSignature: generateSolanaSignature(),
          closeSignature: generateSolanaSignature(),
          jitoTipSol: "0.002500",
          openedAt: new Date(Date.now() - 3600000 * 3),
          closedAt: new Date(Date.now() - 3600000 * 1),
        },
      ]);
    }

    isInitialized = true;
  } catch (err) {
    console.error("ensureDbSeeded error:", err);
  }
}
