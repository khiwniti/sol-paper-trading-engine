// Trading engine math: RSI, MACD, EMA, Bollinger Bands, and MEV arbitrage evaluator

export interface MarketTick {
  price: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  rsi?: number;
  macd?: number;
  signalLine?: number;
  ema9?: number;
  ema21?: number;
  bollingerUpper?: number;
  bollingerLower?: number;
  timestamp: string;
}

export function calculateEMA(prices: number[], period: number): number {
  if (prices.length === 0) return 0;
  if (prices.length < period) return prices[prices.length - 1];
  const k = 2 / (period + 1);
  let ema = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < prices.length; i++) {
    ema = prices[i] * k + ema * (1 - k);
  }
  return ema;
}

export function calculateRSI(prices: number[], period = 14): number {
  if (prices.length <= period) return 50.0;
  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff >= 0) gains += diff;
    else losses -= diff;
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  for (let i = period + 1; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff >= 0) {
      avgGain = (avgGain * (period - 1) + diff) / period;
      avgLoss = (avgLoss * (period - 1)) / period;
    } else {
      avgGain = (avgGain * (period - 1)) / period;
      avgLoss = (avgLoss * (period - 1) - diff) / period;
    }
  }

  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return Number((100 - 100 / (1 + rs)).toFixed(2));
}

export function calculateBollingerBands(prices: number[], period = 20, multiplier = 2): { upper: number; lower: number; middle: number } {
  if (prices.length < period) {
    const last = prices[prices.length - 1] || 150;
    return { upper: last * 1.02, lower: last * 0.98, middle: last };
  }
  const slice = prices.slice(-period);
  const mean = slice.reduce((a, b) => a + b, 0) / period;
  const variance = slice.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / period;
  const stdDev = Math.sqrt(variance);
  return {
    upper: Number((mean + multiplier * stdDev).toFixed(4)),
    lower: Number((mean - multiplier * stdDev).toFixed(4)),
    middle: Number(mean.toFixed(4)),
  };
}

export function generateInitialSeedTicks(basePrice = 178.45, count = 50): MarketTick[] {
  const ticks: MarketTick[] = [];
  let currentPrice = basePrice;
  const pricesHistory: number[] = [];
  const now = Date.now();
  const stepMs = 60 * 1000; // 1 min per candle

  for (let i = count; i >= 0; i--) {
    const time = new Date(now - i * stepMs).toISOString();
    const drift = (Math.random() - 0.49) * 1.25;
    const open = currentPrice;
    currentPrice = Math.max(80, +(open + drift).toFixed(4));
    const high = +(Math.max(open, currentPrice) + Math.random() * 0.85).toFixed(4);
    const low = +(Math.min(open, currentPrice) - Math.random() * 0.85).toFixed(4);
    const close = currentPrice;
    const volume = +(12000 + Math.random() * 85000).toFixed(2);

    pricesHistory.push(close);
    const rsi = calculateRSI(pricesHistory);
    const ema9 = calculateEMA(pricesHistory, 9);
    const ema21 = calculateEMA(pricesHistory, 21);
    const bb = calculateBollingerBands(pricesHistory);

    ticks.push({
      price: close,
      open,
      high,
      low,
      close,
      volume,
      rsi,
      macd: +(ema9 - ema21).toFixed(4),
      signalLine: +((ema9 - ema21) * 0.88).toFixed(4),
      ema9: +ema9.toFixed(4),
      ema21: +ema21.toFixed(4),
      bollingerUpper: bb.upper,
      bollingerLower: bb.lower,
      timestamp: time,
    });
  }

  return ticks;
}

// Generate realistic simulated MEV Jito Bundle Transaction Hash
export function generateSolanaSignature(): string {
  const chars = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  let sig = "";
  for (let i = 0; i < 88; i++) {
    sig += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return sig;
}
