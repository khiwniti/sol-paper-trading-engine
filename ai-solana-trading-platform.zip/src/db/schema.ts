import { pgTable, text, serial, numeric, timestamp, boolean, integer, jsonb } from "drizzle-orm/pg-core";

// Paper trading wallet & agent state
export const botConfig = pgTable("bot_config", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().default("SolAI-Quantum-MEV-v3"),
  isActive: boolean("is_active").notNull().default(true),
  strategy: text("strategy").notNull().default("QUANTUM_MOMENTUM_MEV"), // QUANTUM_MOMENTUM_MEV, MEAN_REVERSION, HIGH_FREQ_SCALP, JITO_SNIPER
  riskLevel: text("risk_level").notNull().default("MODERATE"), // CONSERVATIVE, MODERATE, AGGRESSIVE, DEGEN
  initialUsdcBalance: numeric("initial_usdc_balance", { precision: 16, scale: 4 }).notNull().default("10000.0000"),
  paperUsdcBalance: numeric("paper_usdc_balance", { precision: 16, scale: 4 }).notNull().default("10000.0000"),
  paperSolBalance: numeric("paper_sol_balance", { precision: 16, scale: 6 }).notNull().default("25.500000"),
  stopLossPct: numeric("stop_loss_pct", { precision: 6, scale: 2 }).notNull().default("2.50"),
  takeProfitPct: numeric("take_profit_pct", { precision: 6, scale: 2 }).notNull().default("5.00"),
  jitoTipSol: numeric("jito_tip_sol", { precision: 8, scale: 6 }).notNull().default("0.002500"), // Jito MEV bundle tip
  jitoBundleProtection: boolean("jito_bundle_protection").notNull().default(true),
  maxSlippagePct: numeric("max_slippage_pct", { precision: 6, scale: 2 }).notNull().default("0.40"),
  tradeSizeUsdc: numeric("trade_size_usdc", { precision: 12, scale: 2 }).notNull().default("500.00"),
  autoTradeIntervalSec: integer("auto_trade_interval_sec").notNull().default(6),
  lastRunAt: timestamp("last_run_at", { withTimezone: true }),
  created_at: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updated_at: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

// Real-time market tick & candlestick snapshot history
export const solPriceTicks = pgTable("sol_price_ticks", {
  id: serial("id").primaryKey(),
  price: numeric("price", { precision: 12, scale: 4 }).notNull(),
  open: numeric("open", { precision: 12, scale: 4 }).notNull(),
  high: numeric("high", { precision: 12, scale: 4 }).notNull(),
  low: numeric("low", { precision: 12, scale: 4 }).notNull(),
  close: numeric("close", { precision: 12, scale: 4 }).notNull(),
  volume: numeric("volume", { precision: 16, scale: 2 }).notNull(),
  rsi: numeric("rsi", { precision: 6, scale: 2 }),
  macd: numeric("macd", { precision: 8, scale: 4 }),
  signalLine: numeric("signal_line", { precision: 8, scale: 4 }),
  ema9: numeric("ema9", { precision: 12, scale: 4 }),
  ema21: numeric("ema21", { precision: 12, scale: 4 }),
  bollingerUpper: numeric("bollinger_upper", { precision: 12, scale: 4 }),
  bollingerLower: numeric("bollinger_lower", { precision: 12, scale: 4 }),
  timestamp: timestamp("timestamp", { withTimezone: true }).notNull().defaultNow(),
});

// Orders executed (paper trades & AI execution)
export const trades = pgTable("trades", {
  id: serial("id").primaryKey(),
  tradeType: text("trade_type").notNull(), // BUY, SELL
  tokenPair: text("token_pair").notNull().default("SOL/USDC"),
  solAmount: numeric("sol_amount", { precision: 16, scale: 6 }).notNull(),
  price: numeric("price", { precision: 12, scale: 4 }).notNull(),
  usdcTotal: numeric("usdc_total", { precision: 16, scale: 4 }).notNull(),
  feeUsdc: numeric("fee_usdc", { precision: 10, scale: 4 }).notNull().default("0.0500"),
  jitoTipSol: numeric("jito_tip_sol", { precision: 8, scale: 6 }).notNull().default("0.002500"),
  mevStatus: text("mev_status").notNull().default("BUNDLE_CONFIRMED"), // BUNDLE_CONFIRMED, FRONTRUN_PROTECTED, BACKRUN_SNIPED, NORMAL
  signature: text("signature").notNull(),
  pnlUsdc: numeric("pnl_usdc", { precision: 14, scale: 4 }),
  pnlPct: numeric("pnl_pct", { precision: 8, scale: 2 }),
  reason: text("reason").notNull(), // e.g. "Auto-opened by Engine" / "Auto-closed: Hit Take Profit"
  aiConfidence: numeric("ai_confidence", { precision: 5, scale: 2 }).notNull().default("88.50"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// Autonomous open & closed positions managed strictly by the AI engine
export const positions = pgTable("positions", {
  id: serial("id").primaryKey(),
  tokenPair: text("token_pair").notNull().default("SOL/USDC"),
  positionSide: text("position_side").notNull().default("LONG"), // LONG
  status: text("status").notNull().default("OPEN"), // OPEN, CLOSED
  solAmount: numeric("sol_amount", { precision: 16, scale: 6 }).notNull(),
  entryPrice: numeric("entry_price", { precision: 12, scale: 4 }).notNull(),
  entryUsdc: numeric("entry_usdc", { precision: 16, scale: 4 }).notNull(),
  currentPrice: numeric("current_price", { precision: 12, scale: 4 }).notNull(),
  takeProfitPrice: numeric("take_profit_price", { precision: 12, scale: 4 }).notNull(),
  stopLossPrice: numeric("stop_loss_price", { precision: 12, scale: 4 }).notNull(),
  currentPnlUsdc: numeric("current_pnl_usdc", { precision: 14, scale: 4 }).notNull().default("0.0000"),
  currentPnlPct: numeric("current_pnl_pct", { precision: 8, scale: 2 }).notNull().default("0.00"),
  closePrice: numeric("close_price", { precision: 12, scale: 4 }),
  closeReason: text("close_reason"), // AUTO_TAKE_PROFIT, AUTO_STOP_LOSS, AI_MOMENTUM_EXIT, MEV_PROTECTION_EXIT
  openSignature: text("open_signature").notNull(),
  closeSignature: text("close_signature"),
  jitoTipSol: numeric("jito_tip_sol", { precision: 8, scale: 6 }).notNull().default("0.002500"),
  openedAt: timestamp("opened_at", { withTimezone: true }).notNull().defaultNow(),
  closedAt: timestamp("closed_at", { withTimezone: true }),
});

// Signals emitted by AI and MEV monitor
export const aiSignals = pgTable("ai_signals", {
  id: serial("id").primaryKey(),
  pair: text("pair").notNull().default("SOL/USDC"),
  action: text("action").notNull(), // STRONG_BUY, BUY, HOLD, SELL, STRONG_SELL, MEV_ARBITRAGE
  confidence: numeric("confidence", { precision: 5, scale: 2 }).notNull(),
  targetPrice: numeric("target_price", { precision: 12, scale: 4 }).notNull(),
  stopLossPrice: numeric("stop_loss_price", { precision: 12, scale: 4 }).notNull(),
  rationale: text("rationale").notNull(),
  mevPayload: jsonb("mev_payload"), // simulated jito bundle payload details
  executed: boolean("executed").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// Real-time Sol mempool & MEV block stream simulation
export const mevBundleEvents = pgTable("mev_bundle_events", {
  id: serial("id").primaryKey(),
  bundleHash: text("bundle_hash").notNull(),
  jitoLeader: text("jito_leader").notNull(),
  slot: integer("slot").notNull(),
  blockRewardSol: numeric("block_reward_sol", { precision: 10, scale: 6 }).notNull(),
  protectionType: text("protection_type").notNull(), // PRIVATE_MEMPOOL, SANDWICH_DEFENSE, ARB_BACKRUN
  status: text("status").notNull(), // LANDED, REVERTED, PENDING
  profitSol: numeric("profit_sol", { precision: 10, scale: 6 }).notNull().default("0.000000"),
  timestamp: timestamp("timestamp", { withTimezone: true }).notNull().defaultNow(),
});
